//
//  WKWebViewViewController.swift
//  Alert,Action,WebView,Safari
//
//  Created by Yogesh Patel on 25/11/21.
//

import UIKit
import WebKit

class WKWebViewViewController: UIViewController,WKNavigationDelegate {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.navigationDelegate = self
        
        if let url = URL(string: "https://developer.apple.com"){
            webView.load(URLRequest(url: url))
        }
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
